﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Engine.Mathematics;

namespace Engine
{
    public class Eng_Vector3D
    {
        // Properties
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        // Empty Constructor
        public Eng_Vector3D()
        {
            X = 0;
            Y = 0;
            Z = 0;
        }//eom

        // Greedy Constructor
        public Eng_Vector3D(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }//eom
        #region Class Methods
        // 2.a - Magnitude
        public double Magnitude(double x, double y, double z)
        {
            return Math.Sqrt((x * x) + (y * y) + (z * z));
        }

        // 2.b - 2D Dot Product
        public double DotProduct(Eng_Vector3D A, Eng_Vector3D B)
        {
            return (A.X * B.X) + (A.Y * B.Y) + (A.Z * B.Z);
        }
        // 2.c – Angle between 3D Vectors
        public double Anglebetween(Eng_Vector3D A, Eng_Vector3D B)
        {
            return Math.Acos(DotProduct(A, B) / (Magnitude(A.X, A.Y, A.Z) * Magnitude(B.X, B.Y, B.Z)));
        }


        // 2.d – Normalize 3D Vector
        public Eng_Vector3D Normalize()
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = Math.Round(X / Magnitude(X, Y, Z),4);
            temp.Y = Math.Round(Y / Magnitude(X, Y, Z),4);
            temp.Z = Math.Round(Z / Magnitude(X, Y, Z),4);
            return temp;
        }

        #endregion

        #region Overload Operators
        #region Complier Warning Fix
        // the following two methods are to remove the CS0660 and CS0661 compiler warnings
        public override bool Equals(object obj)
        {
            return true;
        }//eom
        public override int GetHashCode()
        {
            return 0;
        }//eom
        #endregion

        // 3.a  Add 3D Vectors
        static public Eng_Vector3D operator +(Eng_Vector3D a, Eng_Vector3D b)
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = a.X + b.X;
            temp.Y = a.Y + b.Y;
            temp.Z = a.Z + b.Z;
            return temp;
        }
        // 3.a  Subtract 3D Vectors
        static public Eng_Vector3D operator -(Eng_Vector3D a, Eng_Vector3D b)
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = a.X - b.X;
            temp.Y = a.Y - b.Y;
            temp.Z = a.Z - b.Z;
            return temp;
        }
        // 3.b Scale 3D Vector
        static public Eng_Vector3D operator *(double a, Eng_Vector3D b)
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = a * b.X;
            temp.Y = a * b.Y;
            temp.Z = a * b.Z;
            return temp;
        }

        // 3.c Equality of two 3D vectors

        public static bool operator ==(Eng_Vector3D a, Eng_Vector3D b)
        {
            return a.X == b.X && a.Y == b.Y && a.Z == b.Z;
        }//eom

        // 3.c Inequality of two 3D vectors
        public static bool operator !=(Eng_Vector3D a, Eng_Vector3D b)
        {
            return a.X != b.X || a.Y != b.Y || a.Z != b.Z;
        }//eom

        // 3.d Cross Product
        public static Eng_Vector3D operator *(Eng_Vector3D a, Eng_Vector3D b)
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = (a.Y * b.Z) - (a.Z * b.Y);
            temp.Y = (a.X * b.Z) - (a.Z * b.X);
            temp.Z = (a.X * b.Y) - (a.Y * b.X);

            return temp;
        }
        
        // multiply vector3d by matrix 3x3
        public static Eng_Vector3D operator *(Eng_Matrix3x3 a, Eng_Vector3D b)
        {
            Eng_Vector3D temp = new Eng_Vector3D();
            temp.X = (a.M11 * b.X) + (a.M12 * b.Y) + (a.M13 * b.Z);
            temp.Y = (a.M21 * b.X) + (a.M22 * b.Y) + (a.M23 * b.Z);
            temp.Z = (a.M31 * b.X) + (a.M32 * b.Y) + (a.M33 * b.Z);
            return temp;
        }

        #endregion
    }//eoc
}//eon
