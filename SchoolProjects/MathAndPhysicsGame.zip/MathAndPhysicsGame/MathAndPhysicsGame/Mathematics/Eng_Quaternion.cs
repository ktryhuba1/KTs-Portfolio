using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Mathematics
{
    public class Eng_Quaternion
    {
        // Properties
        protected double rollSin, rollCos, pitchSin, pitchCos, yawSin, yawCos;
        public double Qx, Qy, Qz, Qw, eulerX, eulerY, eulerZ;



        // Constructors
        // 2.a
        public Eng_Quaternion(double rollAngle, double pitchAngle, double yawAngle)
        {
            rollAngle = Functions.Radians(rollAngle);
            pitchAngle = Functions.Radians(pitchAngle);
            yawAngle = Functions.Radians(yawAngle);

            rollSin = Math.Sin(rollAngle * 0.5);
            rollCos = Math.Cos(rollAngle * 0.5);

            pitchSin = Math.Sin(pitchAngle * 0.5);
            pitchCos = Math.Cos(pitchAngle * 0.5);

            yawSin = Math.Sin(yawAngle * 0.5);
            yawCos = Math.Cos(yawAngle * 0.5);

            Qw = (yawCos * pitchCos * rollCos) + (yawSin * pitchSin * rollSin);
            Qx = (yawCos * pitchSin * rollCos) + (yawSin * pitchCos * rollSin);
            Qy = (yawSin * pitchCos * rollCos) - (yawCos * pitchSin * rollSin);
            Qz = (yawCos * pitchCos * rollSin) - (yawSin * pitchSin * rollCos);

            eulerX = pitchAngle;
            eulerY = yawAngle;
            eulerZ = rollAngle;
        }

        // 2.b
        public Eng_Quaternion(double qw, double qx, double qy, double qz)
        {
            Qw = qw;
            Qx = qx;
            Qy = qy;
            Qz = qz;

            Tuple<double,double,double> eulerangles = Euler();
            eulerX = eulerangles.Item1;
            eulerY = eulerangles.Item2;
            eulerZ = eulerangles.Item3;

        }

        //2.c

        #region Class Methods
        // 3.a - Create Matrix from Quaternion

        public Eng_Matrix4x4 matrix()
        {
            return new Eng_Matrix4x4(1 - (2 * ((Qy * Qy) + (Qz * Qz))), 2 * ((Qx * Qy) - (Qw * Qz)), 2 * ((Qx * Qz) + (Qw * Qy)), 0, 2 * ((Qx * Qy) + (Qw * Qz)), 1 - (2 * ((Qx * Qx) + (Qz * Qz))), 2 * ((Qy * Qz) - (Qw * Qx)), 0, 2 * ((Qx * Qz) - (Qw * Qy)), 2 * ((Qy * Qz) + (Qw * Qx)), 1 - (2 * ((Qx * Qx) + (Qy * Qy))), 0, 0, 0, 0, 1);
        }


        // 3.b - Create rotation angles (in degrees) from Quaternion
        public Tuple<double, double, double> Euler()
        {
            Eng_Matrix4x4 matrix = this.matrix();

            return new Tuple<double,double,double>(Functions.Degrees(Math.Asin(matrix.M23 * -1)), Functions.Degrees(Math.Atan(matrix.M13 / matrix.M33)), Functions.Degrees(Math.Atan(matrix.M21 / matrix.M22)));
        }
        
        
        #endregion

        #region Overload Operators
        #region Complier Warning Fix
        // the following two methods are to remove the CS0660 and CS0661 compiler warnings
        public override bool Equals(object obj)
        {
            return true;
        }//eom
        public override int GetHashCode()
        {
            return 0;
        }//eom
        #endregion

        // 4.a - Equality of two Quaternions
        public static bool operator ==(Eng_Quaternion a, Eng_Quaternion b)
        {
            return Math.Round(a.Qw, 8) == Math.Round(b.Qw, 8) && Math.Round(a.Qx, 8) == Math.Round(b.Qx, 8) && Math.Round(a.Qy, 8) == Math.Round(b.Qy, 8) && Math.Round(a.Qz, 8) == Math.Round(b.Qz, 8);
        }

        // 4.a - Inequality of two Quaternions
        public static bool operator !=(Eng_Quaternion a, Eng_Quaternion b)
        {
            return Math.Round(a.Qw, 8) != Math.Round(b.Qw, 8) || Math.Round(a.Qx, 8) != Math.Round(b.Qx, 8) || Math.Round(a.Qy, 8) != Math.Round(b.Qy, 8) || Math.Round(a.Qz, 8) != Math.Round(b.Qz, 8);
        }
        #endregion
    }//eoc
}//eon
