﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

#region Additional Namesapces
//using NUnit.Framework;
using Engine.Mathematics;
#endregion

namespace Engine.Mathematics
{
    public class Eng_Vector2D
    {
        // Properties
        public double X { get; set; }
        public double Y { get; set; }

        // Empty Constructor
        public Eng_Vector2D()
        {
            X = 0;
            Y = 0;
        }//eom

        // Greedy Constructor
        public Eng_Vector2D(double x, double y)
        {
            X = x;
            Y = y;
        }//eom

        public Eng_Vector2D(Vector2 vector2)
        {
            X = vector2.X;
            Y = vector2.Y;
        }

        #region Class Methods
        // 2.a - Magnitude
        public double Magnitude(double x, double y)
        {
            return Math.Sqrt((x * x) + (y * y));
        }

        // 2.b - 2D Dot Product
        public double DotProduct(Eng_Vector2D A, Eng_Vector2D B)
        {
            return (A.X * B.X) + (A.Y * B.Y);
        }
        // 2.c – Angle between 2D Vectors
        public double Anglebetween(Eng_Vector2D A, Eng_Vector2D B)
        {
              return Math.Acos(DotProduct(A, B) / (Magnitude(A.X, A.Y) * Magnitude(B.X, B.Y)));
        }

        // 2.d – Normalize 2D Vector
        public Eng_Vector2D Normalize()
        {
            Eng_Vector2D temp = new Eng_Vector2D();
            temp.X = Math.Round(X / Magnitude(X, Y),4);
            temp.Y = Math.Round(Y / Magnitude(X, Y),4);

            return temp;
        }


        #endregion

        #region Overload Operators
        #region Complier Warning Fix
        // the following two methods are to remove the CS0660 and CS0661 compiler warnings
        public override bool Equals(object obj)
        {
            return true;
        }//eom
        public override int GetHashCode()
        {
            return 0;
        }//eom
        #endregion

        // 3.a Add 2D Vectors
		public static Eng_Vector2D operator +(Eng_Vector2D a, Eng_Vector2D b)
        {
            Eng_Vector2D temp = new Eng_Vector2D();
            temp.X = a.X + b.X;
            temp.Y = a.Y + b.Y;
            return temp;
        }
        // 3.a Subtract 2D Vectors
        public static Eng_Vector2D operator -(Eng_Vector2D a, Eng_Vector2D b)
        {
            Eng_Vector2D temp = new Eng_Vector2D();
            temp.X = a.X - b.X;
            temp.Y = a.Y - b.Y;
            return temp;
        }
        // 3.b Scale 2D Vector
        public static Eng_Vector2D operator *(double scale, Eng_Vector2D a)
        {
            Eng_Vector2D temp = new Eng_Vector2D();
            temp.X = scale * a.X;
            temp.Y = scale * a.Y;
            return temp;
        }

        // 3.c Equality of two 2D vectors
        public static bool operator ==(Eng_Vector2D a, Eng_Vector2D b)
        {
            return a.X == b.X && a.Y == b.Y;
        }//eom
        
        // 3.c Inequality of two 2D vectors
        public static bool operator !=(Eng_Vector2D a, Eng_Vector2D b)
        {
            return a.X != b.X || a.Y != b.Y;
        }//eom

        

        #endregion
    }//eoc
}//eom
