using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Mathematics
{
    public class Eng_Matrix3x3
    {
        // Properties
        public double M11, M12, M13,
                       M21, M22, M23,
                        M31, M32, M33;
        // Constructors
        public Eng_Matrix3x3()
        {
            M11 = 0;
            M12 = 0;
            M13 = 0;

            M21 = 0;
            M22 = 0;
            M23 = 0;

            M31 = 0;
            M32 = 0;
            M33 = 0;
        }
        public Eng_Matrix3x3(double M11, double M12, double M13, double M21, double M22, double M23, double M31, double M32, double M33)
        {
            this.M11 = M11;
            this.M12 = M12;
            this.M13 = M13;

            this.M21 = M21;
            this.M22 = M22;
            this.M23 = M23;

            this.M31 = M31;
            this.M32 = M32;
            this.M33 = M33;
        }





        #region Additional Constructors
        // 2.a - Create Identity matrix
        public void Identity()
        {
            M11 = 1;
            M12 = 0;
            M13 = 0;

            M21 = 0;
            M22 = 1;
            M23 = 0;

            M31 = 0;
            M32 = 0;
            M33 = 1;
        }
        // 2.b - Create from angle

        public Eng_Matrix3x3(double degrees)
        {
            double radians = Functions.Radians(degrees);

            M11 = Math.Cos(radians);
            M12 = -Math.Sin(radians);
            M13 = 0;

            M21 = Math.Sin(radians);
            M22 = Math.Cos(radians);
            M23 = 0;

            M31 = 0;
            M32 = 0;
            M33 = 1;

        }




        // 2.c - Create from Transformation (Scale and Shift)
        public Eng_Matrix3x3(double scaleX, double scaleY, double shiftX, double shiftY)
        {

            M11 = scaleX;
            M12 = 0;
            M13 = shiftX;

            M21 = 0;
            M22 = scaleY;
            M23 = shiftY;

            M31 = 0;
            M32 = 0;
            M33 = 1;

        }





        #endregion

        #region Class Methods
        // 3.a - Transpose a matrix
        public Eng_Matrix3x3 Transpose()
        {
            return new Eng_Matrix3x3(M11, M21, M31, M12, M22, M32, M13, M23, M33);
        }


        // 3.b - Determinant of a matrix
        public double CrossDeterm(double r1c1, double r1c2,double r2c1, double r2c2)
        {
            return (r1c1 * r2c2) - (r1c2 * r2c1);
        }
        public double Determinant()
        {
            return (M11 * CrossDeterm(M22,M23,M32,M33)) - (M12 * CrossDeterm(M21, M23, M31, M33)) + (M13 * CrossDeterm(M21, M22, M31, M32));
        }


        // 3.c - Inverse of a matrix
        public Eng_Matrix3x3 Adj()
        {
            Eng_Matrix3x3 adj = new Eng_Matrix3x3();
            adj.M11 = CrossDeterm(M22,M23,M32,M33);
            adj.M12 = -1 * CrossDeterm(M21, M23, M31, M33);
            adj.M13 = CrossDeterm(M21, M22, M31, M32);

            adj.M21 = -1 * CrossDeterm(M12, M13, M32, M33);
            adj.M22 = CrossDeterm(M11, M13, M31, M33);
            adj.M23 = -1 * CrossDeterm(M11, M12, M31, M32);

            adj.M31 = CrossDeterm(M12, M13, M22, M23);
            adj.M32 = -1 * CrossDeterm(M11, M13, M21, M23);
            adj.M33 = CrossDeterm(M11, M12, M21, M22);

            adj = adj.Transpose();
            return adj;
        }

        public Eng_Matrix3x3 Inverse()
        {

            double deteminant = this.Determinant();
            Eng_Matrix3x3 adj = this.Adj();


            return new Eng_Matrix3x3(adj.M11 / deteminant, adj.M12 / deteminant, adj.M13 / deteminant, adj.M21 / deteminant, adj.M22 / deteminant, adj.M23 / deteminant, adj.M31 / deteminant, adj.M32 / deteminant, adj.M33 / deteminant);

        }

        #endregion

        #region Overload Operators
        #region Complier Warning Fix
        // the following two methods are to remove the CS0660 and CS0661 compiler warnings
        public override bool Equals(object obj)
        {
            return true;
        }//eom
        public override int GetHashCode()
        {
            return 0;
        }//eom
        #endregion

        // 4.a - Equality of two 3x3 matrices
        public static bool operator ==(Eng_Matrix3x3 a, Eng_Matrix3x3 b)
        {
            return a.M11 == b.M11 && a.M12 == b.M12 && a.M13 == b.M13 && a.M21 == b.M21 && a.M22 == b.M22 && a.M23 == b.M23 && a.M31 == b.M31 && a.M32 == b.M32 && a.M33 == b.M33;
        }

        // 4.a - Inequality of two 3x3 matrices
        public static bool operator !=(Eng_Matrix3x3 a, Eng_Matrix3x3 b)
        {
            return a.M11 != b.M11 || a.M12 != b.M12 || a.M13 != b.M13 || a.M21 != b.M21 || a.M22 != b.M22 || a.M23 != b.M23 || a.M31 != b.M31 || a.M32 != b.M32 || a.M33 != b.M33;
        }
        // 4.b - Scale a matrix
        public static Eng_Matrix3x3 operator *(double a, Eng_Matrix3x3 b)
        {
            return new Eng_Matrix3x3(b.M11 * a, b.M12 * a, b.M13 * a, b.M21 * a, b.M22 * a, b.M23 * a, b.M31 * a, b.M32 * a, b.M33 * a);
        }

        // 4.c - Multiply two 3x3 matrices
        public static Eng_Matrix3x3 operator *(Eng_Matrix3x3 a, Eng_Matrix3x3 b)
        {
            Eng_Matrix3x3 temp = new Eng_Matrix3x3();
            temp.M11 = (a.M11 * b.M11) + (a.M12 * b.M21) + (a.M13 * b.M31);
            temp.M12 = (a.M11 * b.M12) + (a.M12 * b.M22) + (a.M13 * b.M32);
            temp.M13 = (a.M11 * b.M13) + (a.M12 * b.M23) + (a.M13 * b.M33);
            
            temp.M21 = (a.M21 * b.M11) + (a.M22 * b.M21) + (a.M23 * b.M31);
            temp.M22 = (a.M21 * b.M12) + (a.M22 * b.M22) + (a.M23 * b.M32);
            temp.M23 = (a.M21 * b.M13) + (a.M22 * b.M23) + (a.M23 * b.M33);
            
            temp.M31 = (a.M31 * b.M11) + (a.M32 * b.M21) + (a.M33 * b.M31);
            temp.M32 = (a.M31 * b.M12) + (a.M32 * b.M22) + (a.M33 * b.M32);
            temp.M33 = (a.M31 * b.M13) + (a.M32 * b.M23) + (a.M33 * b.M33);
            
            return temp;
        }
        #endregion
    }//eoc
}//eon
