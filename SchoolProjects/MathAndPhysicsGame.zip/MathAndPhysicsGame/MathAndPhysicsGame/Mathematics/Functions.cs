﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Mathematics
{
    public class Functions
    {
        #region Class Variables
        private static double pi = Math.PI;
        #endregion

        #region Methods for later use

        #endregion

        #region General Math
        // 1.a - Degrees to Radians

        /// <summary>
        /// Converts Degrees to Radians
        /// </summary>
        public static double Radians(double X)
        {
            X = X * pi / 180;
            return X;
        }
        //rad = deg * pi/180
        // 1.b - Radians to Degrees
        /// <summary>
        /// Converts Radians to Degrees
        /// </summary>
        public static double Degrees(double X)
        {
            X = X * 180 / pi;
            return X;
        }       
        #endregion

        #region Solve Right Triangles
        // 1.c - Solve for Adjacent & Opposite
        public static Tuple<double,double> AdjacentAndOpposite(double theta, double hyp)
        {
            double Adj = Math.Cos(theta) * hyp;
            double Opp = Math.Sin(theta) * hyp;
            return new Tuple<double, double>(Adj, Opp);
        }
       
        // 1.d – Solve for Adjacent & Hypotenuse
        public static Tuple<double,double> AdjacentAndHypotenuse(double theta, double opp)
        {
            double Adj = opp / Math.Tan(theta);
            double Hyp = opp / Math.Sin(theta);
            return new Tuple<double, double>(Adj, Hyp);
        }

        // 1.e – Solve for Opposite & Hypotenuse
        public static Tuple<double, double> OppositeAndHypotenuse(double theta, double adj)
        {
            double Opp = Math.Tan(theta) * adj;
            double Hyp = adj / Math.Cos(theta);
            return new Tuple<double, double>(Opp, Hyp);
        }
        // 1.f – Solve for Hypotenuse & Theta
        public static Tuple<double, double> HypotenuseAndTheta(double adjacent, double opposite)
        {
            double Hyp = Math.Sqrt((opposite * opposite)+(adjacent * adjacent));
            double Theta = Math.Atan(opposite / adjacent);
            return new Tuple<double, double>(Hyp,Theta);
        }
        // 1.g – Solve for Adjacent & Theta
        public static Tuple<double, double> AdjacentAndTheta(double opposite, double hypotenuse)
        {
            double Adj = Math.Sqrt((hypotenuse * hypotenuse) - (opposite * opposite));
            double Theta = Math.Atan(opposite/Adj);
            return new Tuple<double, double>(Adj, Theta);
        }
        // 1.h – Solve for Opposite & Theta
        public static Tuple<double, double> OppositeAndTheta(double adjacent, double hypotenuse)
        {
            double Opp = Math.Sqrt((hypotenuse * hypotenuse) - (adjacent * adjacent));
            double Theta = Math.Atan(Opp / adjacent);
            return new Tuple<double, double>(Opp, Theta);
        }
        #endregion

        #region Lab 4 - Part 1: Bezier Curves
        // 1.a - Quadratic Bezier 2D
        public static Eng_Vector2D QuadraticBezier(
            double t, Eng_Vector2D p0, Eng_Vector2D p1, Eng_Vector2D p2)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double t2 = t * t;
            double X = p0.X * ts2 + 2 * p1.X * t * ts + p2.X * t2;
            double Y = p0.Y * ts2 + 2 * p1.Y * t * ts + p2.Y * t2;
            return new Eng_Vector2D(X, Y);
        }//eom

        // 1.b - Cubic Bezier 2D
        public static Eng_Vector2D CubicBezier(
            double t, Eng_Vector2D p0, Eng_Vector2D p1, Eng_Vector2D p2, Eng_Vector2D p3)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double ts3 = ts2 * ts;
            double t2 = t * t;
            double t3 = t2 * t;
            double X = p0.X * ts3 + 3 * t * p1.X * ts2 + 3 * p2.X * t2 * ts + p3.X * t3;
            double Y = p0.Y * ts3 + 3 * t * p1.Y * ts2 + 3 * p2.Y * t2 * ts + p3.Y * t3;
            return new Eng_Vector2D(X, Y);
        }//eom

        // 1.c - Quartic Bezier 2D
        public static Eng_Vector2D QuarticBezier(
            double t, Eng_Vector2D p0, Eng_Vector2D p1, Eng_Vector2D p2,
            Eng_Vector2D p3, Eng_Vector2D p4)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double ts3 = ts2 * ts;
            double ts4 = ts3 * ts;
            double t2 = t * t;
            double t3 = t2 * t;
            double t4 = t3 * t;
            double X = p0.X * ts4 + 4 * p1.X * t * ts3 + 6 * p2.X * t2 * ts2 + 4 * p3.X * t3 * ts + t4 * p4.X;
            double Y = p0.Y * ts4 + 4 * p1.Y * t * ts3 + 6 * p2.Y * t2 * ts2 + 4 * p3.Y * t3 * ts + t4 * p4.Y;
            return new Eng_Vector2D(X, Y);
        }//eom

        // 1.d - Quadratic Bezier 3D
        public static Eng_Vector3D QuadraticBezier(
            double t, Eng_Vector3D p0, Eng_Vector3D p1, Eng_Vector3D p2)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double t2 = t * t;
            double X = p0.X * ts2 + 2 * p1.X * t * ts + p2.X * t2;
            double Y = p0.Y * ts2 + 2 * p1.Y * t * ts + p2.Y * t2;
            double Z = p0.Z * ts2 + 2 * p1.Z * t * ts + p2.Z * t2;
            return new Eng_Vector3D(X, Y, Z);
        }//eom

        // 1.e - Cubic Bezier 3D
        public static Eng_Vector3D CubicBezier(
            double t, Eng_Vector3D p0, Eng_Vector3D p1, Eng_Vector3D p2, Eng_Vector3D p3)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double ts3 = ts2 * ts;
            double t2 = t * t;
            double t3 = t2 * t;
            double X = p0.X * ts3 + 3 * t * p1.X * ts2 + 3 * p2.X * t2 * ts + p3.X * t3;
            double Y = p0.Y * ts3 + 3 * t * p1.Y * ts2 + 3 * p2.Y * t2 * ts + p3.Y * t3;
            double Z = p0.Z * ts3 + 3 * t * p1.Z * ts2 + 3 * p2.Z * t2 * ts + p3.Z * t3;
            return new Eng_Vector3D(X, Y, Z);
        }//eom

        // 1.f - Quartic Bezier 3D
        public static Eng_Vector3D QuarticBezier(
            double t, Eng_Vector3D p0, Eng_Vector3D p1, Eng_Vector3D p2,
            Eng_Vector3D p3, Eng_Vector3D p4)
        {
            double ts = 1 - t;
            double ts2 = ts * ts;
            double ts3 = ts2 * ts;
            double ts4 = ts3 * ts;
            double t2 = t * t;
            double t3 = t2 * t;
            double t4 = t3 * t;
            double X = p0.X * ts4 + 4 * p1.X * t * ts3 + 6 * p2.X * t2 * ts2 + 4 * p3.X * t3 * ts + t4 * p4.X;
            double Y = p0.Y * ts4 + 4 * p1.Y * t * ts3 + 6 * p2.Y * t2 * ts2 + 4 * p3.Y * t3 * ts + t4 * p4.Y;
            double Z = p0.Z * ts4 + 4 * p1.Z * t * ts3 + 6 * p2.Z * t2 * ts2 + 4 * p3.Z * t3 * ts + t4 * p4.Z;
            return new Eng_Vector3D(X, Y, Z);
        }//eom
        #endregion

        #region Lab 4 - Part 2: Catmul-Rom Splines
        // 1.a - 2D Spline
        public static Eng_Vector2D CatmullRomSpline(
            double t, Eng_Vector2D p0, Eng_Vector2D p1, Eng_Vector2D p2, Eng_Vector2D p3)
        {
            double t2 = t * t;
            double t3 = t2 * t;
            double X = 0.5f * ((2 * p1.X) + (p2.X - p0.X) * t + (2 * p0.X - 5 * p1.X + 4 * p2.X - p3.X) * t2 + (p3.X - p0.X + 3 * p1.X - 3 * p2.X) * t3);
            double Y = 0.5f * ((2 * p1.Y) + (p2.Y - p0.Y) * t + (2 * p0.Y - 5 * p1.Y + 4 * p2.Y - p3.Y) * t2 + (p3.Y - p0.Y + 3 * p1.Y - 3 * p2.Y) * t3);
            return new Eng_Vector2D(X, Y);
        }//eom

        // 1.b - 3D Spline
        public static Eng_Vector3D CatmullRomSpline(
            double t, Eng_Vector3D p0, Eng_Vector3D p1, Eng_Vector3D p2, Eng_Vector3D p3)
        {
            double t2 = t * t;
            double t3 = t2 * t;
            double X = 0.5f * ((2 * p1.X) + (p2.X - p0.X) * t + (2 * p0.X - 5 * p1.X + 4 * p2.X - p3.X) * t2 + (p3.X - p0.X + 3 * p1.X - 3 * p2.X) * t3);
            double Y = 0.5f * ((2 * p1.Y) + (p2.Y - p0.Y) * t + (2 * p0.Y - 5 * p1.Y + 4 * p2.Y - p3.Y) * t2 + (p3.Y - p0.Y + 3 * p1.Y - 3 * p2.Y) * t3);
            double Z = 0.5f * ((2 * p1.Z) + (p2.Z - p0.Z) * t + (2 * p0.Z - 5 * p1.Z + 4 * p2.Z - p3.Z) * t2 + (p3.Z - p0.Z + 3 * p1.Z - 3 * p2.Z) * t3);
            return new Eng_Vector3D(X, Y, Z);
        }//eom
        #endregion


    }//eoc
}//eon
