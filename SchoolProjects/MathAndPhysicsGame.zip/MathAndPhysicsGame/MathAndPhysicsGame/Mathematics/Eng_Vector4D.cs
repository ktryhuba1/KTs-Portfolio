using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Mathematics
{
    public class Eng_Vector4D
    {
        // Properties
        public double X, Y, Z, W;
        // Constructors
        public Eng_Vector4D()
        {
            X = 0;
            Y = 0;
            Z = 0;
            W = 0;
        }

        public Eng_Vector4D(double x, double y, double z, double w)
        {
            X = x;
            Y = y;
            Z = z;
            W = w;
        }


        // 5.a Create a 4D vector from a 3D vector
        public Eng_Vector4D(Eng_Vector3D a)
        {
            X = a.X;
            Y = a.Y;
            Z = a.Z;
            W = 1;
        }

        #region Overload Operators
        #region Complier Warning Fix
        // the following two methods are to remove the CS0660 and CS0661 compiler warnings
        public override bool Equals(object obj)
        {
            return true;
        }//eom
        public override int GetHashCode()
        {
            return 0;
        }//eom
        #endregion

        // 5.b Equality of two 4D vectors
        public static bool operator ==(Eng_Vector4D a, Eng_Vector4D b)
        {
            return a.X == b.X && a.Y == b.Y && a.Z == b.Z && a.W == b.W;
        }//eom

        // 5.b Inequality of two 4D vectors
        public static bool operator !=(Eng_Vector4D a, Eng_Vector4D b)
        {
            return a.X != b.X || a.Y != b.Y || a.Z != b.Z || a.W != b.W;
        }//eom

        // 5.c Multiply 4D vector by Eng_Matrix4x4
        public static Eng_Vector4D operator *(Eng_Matrix4x4 a, Eng_Vector4D b)
        {
            Eng_Vector4D temp = new Eng_Vector4D();

            temp.X = (a.M11 * b.X) + (a.M12 * b.Y) + (a.M13 * b.Z) + (a.M14 * b.W);
            temp.Y = (a.M21 * b.X) + (a.M22 * b.Y) + (a.M23 * b.Z) + (a.M24 * b.W);
            temp.Z = (a.M31 * b.X) + (a.M32 * b.Y) + (a.M33 * b.Z) + (a.M34 * b.W);
            temp.W = (a.M41 * b.X) + (a.M42 * b.Y) + (a.M43 * b.Z) + (a.M44 * b.W);

            return temp;
        }


        // 5.d Multiply 4D vector by Eng_Quaternion
        public static Eng_Vector4D operator *(Eng_Quaternion a, Eng_Vector4D b)
        {
            return a.matrix() * b;
        }

        #endregion
    }//eoc
}//eon
