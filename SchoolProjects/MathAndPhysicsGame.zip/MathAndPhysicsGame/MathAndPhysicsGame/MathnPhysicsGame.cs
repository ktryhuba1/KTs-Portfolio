﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

#region Additional namespaces
using Engine.Mathematics;
#endregion

namespace MathAndPhysicsGame
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class MathnPhysicsGame : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont arial;

        const int windowHeight = 800;
        const int windowWidth = 1800;
        protected Rectangle GameBoard = new Rectangle(0, 0, windowWidth, windowHeight);

        Texture2D StartingBox, FinishingBox, LinePoint;
        Rectangle startingRec, finishingRec, pointRec,finishRec,button;
        Vector2 buttonString, menuString;
        string buttonMsg, menuMsg;

        Vector2 currentMousePos = Vector2.Zero;
        Vector2 currentDrawPos = Vector2.Zero;
        MouseState currentMouseState,previousMouseState;
        KeyboardState keyState, previousKeystate;


        Vector2[] controlPoints;
        int controlPointCount, cpcCheck;
        string[] controlPointMsgs;

        Eng_Vector2D[] DotsOnTheLine = new Eng_Vector2D[101];

        Blockers blockers;
        int numBlockers;
        bool LineGotThrough = false, challengeMode = false;

        int level;
        int maxLevel = 10;
        

        Color buttonColor, cursorColor, controlPointsColor;

        enum GameStates
        {
            initialize,
            menu,
            playing,
            replay,
            over
        }
        GameStates currentGameState,previousGameState;


        public MathnPhysicsGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferHeight = windowHeight;
            graphics.PreferredBackBufferWidth = windowWidth;
            graphics.ApplyChanges();
            numBlockers = 3;
            blockers = new Blockers(numBlockers);
            level = 1;
            currentGameState = GameStates.initialize;
            previousGameState = GameStates.over;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            arial = Content.Load<SpriteFont>("SystemArialFont");
            StartingBox = Content.Load<Texture2D>("Paddle");
            FinishingBox = Content.Load<Texture2D>("Paddle");
            LinePoint = Content.Load<Texture2D>("Ball");
            blockers.LoadContent(Content);
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            currentMouseState = Mouse.GetState();
            currentMousePos = new Vector2(currentMouseState.Position.X, currentMouseState.Position.Y);
            currentDrawPos = new Vector2(currentMousePos.X - (LinePoint.Width), currentMousePos.Y - (LinePoint.Height));
            keyState = Keyboard.GetState();


            switch (currentGameState)
            {

                case GameStates.initialize:
                    startingRec = new Rectangle((int)windowWidth / 9, (int)windowHeight / 2, (int)windowHeight / 20, (int)windowHeight / 20);
                    finishingRec = new Rectangle(windowWidth - (int)windowWidth / 8, (int)windowHeight / 2, (int)windowHeight / 20, (int)windowHeight / 20);
                    controlPoints = new Vector2[3];
                    controlPointMsgs = new string[3];
                    for (int c = 0; c < controlPoints.Length; c++)
                    {
                        controlPoints[c] = new Vector2(-100,-100);
                        controlPointMsgs[c] = "";
                    }

                    for (int c = 0; c < DotsOnTheLine.Length; c++)
                    {
                        DotsOnTheLine[c] = new Eng_Vector2D(-100,-100);
                    }
                    buttonMsg = "";
                    menuMsg = "";

                    blockers = new Blockers(numBlockers);
                    blockers.LoadContent(Content);
                    blockers.Initialize(GameBoard);
                    controlPointCount = 0;
                    cpcCheck = 999;
                    LineGotThrough = false;


                    buttonColor = Color.DarkBlue;
                    cursorColor = Color.AntiqueWhite;
                    controlPointsColor = Color.Yellow;

                    if (previousGameState == GameStates.playing)
                    {
                        previousGameState = currentGameState;
                        currentGameState = GameStates.playing;                        
                    }
                    else
                    {
                        previousGameState = currentGameState;
                        currentGameState = GameStates.menu;
                    }


                    break;
                case GameStates.menu:

                    menuMsg = "To Play click the screen to add a control point\n(up to three) then hit Go to see if your results\nCan you dodge the Pink boxes?\nbeat "+maxLevel+" Levels to win\nPress U to undo, or R for Reset";

                    button = new Rectangle((int)(windowWidth * 0.65), (int)(windowHeight * 0.75), (int)windowWidth / 10, (int)windowHeight / 10);

                    if (keyState.IsKeyDown(Keys.K)&&keyState.IsKeyDown(Keys.T))
                    {
                        challengeMode = true;
                    }

                    if (challengeMode)
                    {
                        buttonMsg = "HARD MODE";
                        maxLevel = 25;
                    }
                    else
                    {
                        buttonMsg = "PLAY";
                        maxLevel = 10;
                    }

                        
                    if(currentMouseState.LeftButton == ButtonState.Pressed && button.Contains(currentMousePos))
                    {
                        menuMsg = "";
                        previousGameState = currentGameState;
                        currentGameState = GameStates.playing;
                    }


                    break;
                case GameStates.playing:

                    button = new Rectangle((int)(windowWidth * 0.75), (int)(windowHeight * 0.8), (int)windowWidth / 7, (int)windowHeight / 12);


                    buttonMsg = "GO!";
                    pointRec = new Rectangle((int)(startingRec.Center.X - (LinePoint.Width / 2)), startingRec.Center.Y - (LinePoint.Height / 2), LinePoint.Width, LinePoint.Height);
                    finishRec = new Rectangle((int)(finishingRec.Center.X - (LinePoint.Width / 2)), finishingRec.Center.Y - (LinePoint.Height / 2), LinePoint.Width, LinePoint.Height);




                    if (controlPointCount < 3 && currentMouseState.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton != ButtonState.Pressed && GameBoard.Contains(currentMousePos) && !button.Contains(currentMousePos))
                    {
                        controlPoints[controlPointCount] = currentMousePos;
                        controlPointMsgs[controlPointCount] = " "+ (controlPointCount+1) +") " + currentMousePos.X + ", " + currentMousePos.Y;
                        
                        controlPointCount++;

                    }


                    if (currentMouseState.LeftButton == ButtonState.Pressed && button.Contains(currentMousePos) && previousMouseState.LeftButton != ButtonState.Pressed || keyState.IsKeyDown(Keys.Space) && !previousKeystate.IsKeyDown(Keys.Space))
                    {

                        if (LineGotThrough && cpcCheck == controlPointCount)
                        {
                            level++;
                            if(challengeMode)
                            {
                                numBlockers++;
                            }
                            currentMouseState = previousMouseState;
                            previousGameState = currentGameState;
                            currentGameState = GameStates.initialize;
                        }

                        //count the control points, and call the appropriate bezier/ curve method
                        switch (controlPointCount)
                        {
                            case 0:
                                cpcCheck = controlPointCount;
                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = Functions.QuadraticBezier(c * 0.01, new Eng_Vector2D(pointRec.Location.ToVector2()), new Eng_Vector2D(GameBoard.Width / 2,pointRec.Location.ToVector2().Y), new Eng_Vector2D(finishRec.Location.ToVector2()));
                                    if (blockers.checkForHit(DotsOnTheLine[c], LinePoint.Width / 2))
                                    {
                                        LineGotThrough = false;
                                        previousGameState = currentGameState;
                                        currentGameState = GameStates.over;
                                        break;
                                    }
                                }
                                LineGotThrough = true;


                                break;
                            case 1:
                                cpcCheck = controlPointCount;
                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = Functions.QuadraticBezier(c* 0.01, new Eng_Vector2D(pointRec.Location.ToVector2()), new Eng_Vector2D(controlPoints[0]), new Eng_Vector2D(finishRec.Location.ToVector2()));
                                    if(blockers.checkForHit(DotsOnTheLine[c], LinePoint.Width / 2))
                                    {
                                        LineGotThrough = false;
                                        previousGameState = currentGameState;
                                        currentGameState = GameStates.over;
                                        break;
                                    }
                                }
                                LineGotThrough = true;

                                break;
                            case 2:
                                cpcCheck = controlPointCount;
                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = new Eng_Vector2D(-100, -100);
                                }

                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = Functions.CubicBezier(c * 0.01, new Eng_Vector2D(pointRec.Location.ToVector2()), new Eng_Vector2D(controlPoints[0]), new Eng_Vector2D(controlPoints[1]), new Eng_Vector2D(finishRec.Location.ToVector2()));
                                    if (blockers.checkForHit(DotsOnTheLine[c],LinePoint.Width / 2))
                                    {
                                        LineGotThrough = false;
                                        previousGameState = currentGameState;
                                        currentGameState = GameStates.over;
                                        break;
                                    }
                                }

                                LineGotThrough = true;
                                break;
                            case 3:
                                cpcCheck = controlPointCount;
                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = new Eng_Vector2D(-100, -100);
                                }

                                for (int c = 0; c < DotsOnTheLine.Length; c++)
                                {
                                    DotsOnTheLine[c] = Functions.QuarticBezier(c * 0.01, new Eng_Vector2D(pointRec.Location.ToVector2()), new Eng_Vector2D(controlPoints[0]), new Eng_Vector2D(controlPoints[1]), new Eng_Vector2D(controlPoints[2]), new Eng_Vector2D(finishRec.Location.ToVector2()));
                                    if (blockers.checkForHit(DotsOnTheLine[c],LinePoint.Width / 2))
                                    {
                                        LineGotThrough = false;
                                        previousGameState = currentGameState;
                                        currentGameState = GameStates.over;
                                        break;
                                    }
                                }
                                LineGotThrough = true;
                                break;
                            default:
                                break;
                        }                                               
                    }

                    

                    if (keyState.IsKeyDown(Keys.R))
                    {
                        previousGameState = currentGameState;
                        currentGameState = GameStates.initialize;
                    }

                    if (keyState.IsKeyDown(Keys.U))
                    {
                        previousGameState = currentGameState;
                        currentGameState = GameStates.replay;
                    }


                    if (challengeMode)
                    {
                        if (level >= 25)
                        {
                            menuMsg = "Your a Master!";
                            currentGameState = GameStates.over;
                        }
                    }
                    else
                    {
                        if (level >= 10)
                        {
                            menuMsg = "Your Amazing!\nSecret code: KT";
                            currentGameState = GameStates.over;
                        }
                    }


                    break;
                case GameStates.replay:
                    for (int c = 0; c < controlPoints.Length; c++)
                    {
                        controlPoints[c] = new Vector2(-100, -100);
                        controlPointMsgs[c] = "";
                    }
                    controlPointCount = 0;
                    cpcCheck = 999;
                    for (int c = 0; c < DotsOnTheLine.Length; c++)
                    {
                        DotsOnTheLine[c] = new Eng_Vector2D(-100, -100);
                    }
                    currentGameState = GameStates.playing;
                    break;
                case GameStates.over:
                    buttonMsg = "Main Menu";
                    
 
                    if (currentMouseState.LeftButton == ButtonState.Pressed && button.Contains(currentMousePos) && previousMouseState.LeftButton != ButtonState.Pressed)
                    {
                        level = 1;
                        numBlockers = 3;
                        challengeMode = false;
                        previousGameState = currentGameState;
                        currentGameState = GameStates.initialize;
                    }

                    if(keyState.IsKeyDown(Keys.R))
                    {
                        previousGameState = GameStates.playing;
                        currentGameState = GameStates.initialize;
                    }

                    if (keyState.IsKeyDown(Keys.U))
                    {
                        previousGameState = currentGameState;
                        currentGameState = GameStates.replay;
                    }

                    break;
                default:
                    break;
            }

            buttonString = new Vector2(button.Center.X - (arial.MeasureString(buttonMsg).X / 2), button.Center.Y - (arial.MeasureString(buttonMsg).Y / 2));
            menuString = new Vector2(GameBoard.Center.X - (arial.MeasureString(menuMsg).X / 2), GameBoard.Center.Y - (arial.MeasureString(menuMsg).Y / 2));


            previousKeystate = keyState;
            previousMouseState = currentMouseState;
            base.Update(gameTime);
        }


        

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();


            switch (currentGameState)
            {
                case GameStates.menu:
                    spriteBatch.DrawString(arial, "Bezier Block Dodge!", Vector2.Zero, Color.Black, 0f, Vector2.Zero, 10f, SpriteEffects.None, 1f);
                    spriteBatch.DrawString(arial, menuMsg, menuString, Color.Red);
                    spriteBatch.Draw(StartingBox, button, Color.Purple);
                    spriteBatch.DrawString(arial, buttonMsg,buttonString, Color.White);
                    break;
                case GameStates.playing:
                  
                case GameStates.replay:
               
                case GameStates.over:
                    spriteBatch.Draw(StartingBox, button, buttonColor);
                    spriteBatch.DrawString(arial, buttonMsg, buttonString, Color.White);
                    spriteBatch.Draw(StartingBox, startingRec, Color.MonoGameOrange);
                    spriteBatch.Draw(FinishingBox, finishingRec, Color.LawnGreen);
                    spriteBatch.Draw(LinePoint, pointRec, Color.Black);

                    
                    foreach(var dot in DotsOnTheLine)
                    {
                        spriteBatch.Draw(LinePoint, new Vector2((float)dot.X, (float)dot.Y), Color.Black);
                    }
                    blockers.Draw(spriteBatch);
                    for (int c = 0; c < controlPoints.Length; c++)
                    {
                        spriteBatch.Draw(LinePoint, controlPoints[c], controlPointsColor);
                        spriteBatch.DrawString(arial, controlPointMsgs[c], controlPoints[c], controlPointsColor);
                    }

                    spriteBatch.DrawString(arial, menuMsg, menuString, Color.Red);

                    break;
                default:
                    break;
            }

            spriteBatch.Draw(LinePoint, new Rectangle((int)currentDrawPos.X, (int)currentDrawPos.Y, (int)LinePoint.Width * 2, (int)LinePoint.Height * 2),cursorColor);

            

            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
