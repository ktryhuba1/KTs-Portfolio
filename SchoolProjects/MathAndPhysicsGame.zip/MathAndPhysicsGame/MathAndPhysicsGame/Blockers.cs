﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
#region Additional namespaces
using Engine.Mathematics;
#endregion


namespace MathAndPhysicsGame
{
    class Blockers
    {
        Texture2D blockerWall;


        Rectangle blockerSpawnArea;
        internal Rectangle[] blockers;
        Vector2[] positions;
        Random rng = new Random();
        int width,height;

        public Blockers()
        {
            blockers = new Rectangle[1];
            positions = new Vector2[1];
        }

        public Blockers(int num)
        {
            blockers = new Rectangle[num];
            positions = new Vector2[num];
        }

        public void Initialize(Rectangle gameBoard)
        {
            blockerSpawnArea = new Rectangle((int)(gameBoard.Width * 0.25), (int)(gameBoard.Height * 0.1), (int)(gameBoard.Width * 0.5), (int)(gameBoard.Height * 0.8));
            
            if (blockers.Length <= 35)
            {
                height = (int)(blockerSpawnArea.Height * 0.75) / blockers.Length;
                width = blockerSpawnArea.Width / 9;
            }
            else
            {
                height = (int)(blockerSpawnArea.Height * 0.75) / 35;
                width = (int)(blockerSpawnArea.Width / 9) - (-35 + blockers.Length);
            }


            for(int c=0;c<blockers.Length;c++)
            {
                positions[c].X = rng.Next(blockerSpawnArea.X, blockerSpawnArea.Right - width);
                positions[c].Y = rng.Next(blockerSpawnArea.Top, blockerSpawnArea.Bottom - height);

                blockers[c] = new Rectangle((int)positions[c].X, (int)positions[c].Y,width,height);
            }

        }

        public void LoadContent(ContentManager content)
        {
            blockerWall = content.Load<Texture2D>("Paddle");
        }
        public void Update(GameTime gameTime)
        {
            
        }

        public void Draw(SpriteBatch spritebatch)
        {
            foreach (var rec in blockers)
            {
                spritebatch.Draw(blockerWall, rec, Color.Orchid);
            }
        }

        public bool checkForHit(Eng_Vector2D position, float halfDotwidth)
        {
            Vector2 dot = new Vector2((float)position.X + halfDotwidth,(float)position.Y + halfDotwidth); 
            foreach(var rec in blockers)
            {
                if(rec.Contains(dot))
                {
                    return true;
                }
            }

            return false;
        }


    }
}
