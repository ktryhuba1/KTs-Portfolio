﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Lesson07
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class TicTacToe : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        protected SpriteFont arial;

        string words = "";
        string winner = "";

        const int windowWidth = 172;
        const int windowHeight = 172;

        Texture2D background;
        Texture2D Oimage;
        Texture2D Ximage;
        Texture2D Winner;
        

        Vector2 currentMousePos = Vector2.Zero;
        Vector2 currentDrawPos = Vector2.Zero;
        MouseState currentMouseState;
        MouseState previousMouseState;


        public enum GameSpaceState
        {
            Empty,
            X,
            O,
            Winning
        }
        public enum GameState
        {
            Initialize,
            WaitForPlayerMove,
            MakePlayerMove,
            EvalPlayerMove,
            GameOver
        }
       

        Rectangle[,] GameBoardSpaces = 
        {
            {new Rectangle(new Point(0, 0), new Point(55, 55)),  new Rectangle(new Point(58, 0), new Point(55, 55)),  new Rectangle(new Point(116, 0), new Point(55, 55)) },
            {new Rectangle(new Point(0, 58), new Point(55, 55)),  new Rectangle(new Point(58, 58), new Point(55,55)),  new Rectangle(new Point(116, 58), new Point(55,55)) },
            {new Rectangle(new Point(0, 116), new Point(55, 55)),  new Rectangle(new Point(58, 116), new Point(55,55)),  new Rectangle(new Point(116, 116), new Point(55,55)) }
        };

        
        protected GameState currentGameState = GameState.Initialize;
        protected GameSpaceState nextTokenToBePlayed = GameSpaceState.X;

        GameSpaceState[,] GameArray;
        GameSpaceState[,] GameCheckArray;



        public TicTacToe()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }


        protected override void Initialize()
        {
            graphics.PreferredBackBufferHeight = windowHeight;
            graphics.PreferredBackBufferWidth = windowWidth;
            graphics.ApplyChanges();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            
            spriteBatch = new SpriteBatch(GraphicsDevice);

            background = Content.Load<Texture2D>("TicTacToeBoard");
            Oimage = Content.Load<Texture2D>("O");
            Ximage = Content.Load<Texture2D>("X");
            

            arial = Content.Load<SpriteFont>("SystemArialFont");
           
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            currentMouseState = Mouse.GetState();
            currentMousePos = new Vector2(currentMouseState.Position.X, currentMouseState.Position.Y);
            currentDrawPos = new Vector2(currentMousePos.X - (Ximage.Width / 2), currentMousePos.Y - (Ximage.Height / 2));


            //switch -tab, type name - right arrow to autofill
            switch (currentGameState)
            {
                case GameState.Initialize:

                    nextTokenToBePlayed = GameSpaceState.X;

                    words = "";
                    winner = "";
                    GameArray = new GameSpaceState[,] {
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty},
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty},
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty}
                                };
                    GameCheckArray = new GameSpaceState[,] {
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty},
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty},
                                    {GameSpaceState.Empty,GameSpaceState.Empty,GameSpaceState.Empty}
                                };

                    currentGameState = GameState.WaitForPlayerMove;

                    break;
                case GameState.WaitForPlayerMove:

                    if (currentMouseState.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton != ButtonState.Pressed)
                    {
                        currentGameState = GameState.MakePlayerMove;
                    }

                    break;
                case GameState.MakePlayerMove:

                    for (int row = 0; row < GameArray.GetLength(0); row++)
                    {
                        for (int col = 0; col < GameArray.GetLength(1); col++)
                        {
                            if (GameBoardSpaces[row, col].Contains(currentMousePos.ToPoint()))
                            {
                                if (GameArray[row, col] == GameSpaceState.Empty)
                                {
                                    GameArray[row, col] = nextTokenToBePlayed;


                                    if (nextTokenToBePlayed == GameSpaceState.X)
                                    {
                                        nextTokenToBePlayed = GameSpaceState.O;
                                    }
                                    else if (nextTokenToBePlayed == GameSpaceState.O)
                                    {
                                        nextTokenToBePlayed = GameSpaceState.X;
                                    }
                                    
                                }
                                else
                                {
                                    currentGameState = GameState.WaitForPlayerMove;
                                }
                                break;
                            }
                        }

                    }

                    currentGameState = GameState.EvalPlayerMove;
                    break;
                case GameState.EvalPlayerMove:
                                   
           
                    //Horiontal checks
                    //row 1
                    if (GameArray[0, 0] == GameArray[0,1] && GameArray[0, 1] == GameArray[0,2] && GameArray[0,0] != GameSpaceState.Empty)
                    {
                        words += "Row 1 ";

                        if (GameArray[0, 0] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[0, 0] = GameSpaceState.Winning;
                        GameCheckArray[0, 1] = GameSpaceState.Winning;
                        GameCheckArray[0, 2] = GameSpaceState.Winning;

                    }
                    //row 2
                    if (GameArray[1, 0] == GameArray[1, 1] && GameArray[1, 1] == GameArray[1, 2] && GameArray[1, 0] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                            words += "Row 2 ";

                        if (GameArray[1, 0] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[1, 0] = GameSpaceState.Winning;
                        GameCheckArray[1, 1] = GameSpaceState.Winning;
                        GameCheckArray[1, 2] = GameSpaceState.Winning;
                    }
                    //row 3
                    if (GameArray[2, 0] == GameArray[2, 1] && GameArray[2, 1] == GameArray[2, 2] && GameArray[2, 0] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Row 3 ";

                        if (GameArray[2, 0] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[2, 0] = GameSpaceState.Winning;
                        GameCheckArray[2, 1] = GameSpaceState.Winning;
                        GameCheckArray[2, 2] = GameSpaceState.Winning;
                    }
                    //Vertical checks
                    //col 1
                    if (GameArray[0, 0] == GameArray[1, 0] && GameArray[1, 0] == GameArray[2, 0] && GameArray[0, 0] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Col 1 ";

                        if (GameArray[0, 0] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[0, 0] = GameSpaceState.Winning;
                        GameCheckArray[1, 0] = GameSpaceState.Winning;
                        GameCheckArray[2, 0] = GameSpaceState.Winning;
                    }
                    //col 2
                    if (GameArray[0, 1] == GameArray[1, 1] && GameArray[1, 1] == GameArray[2, 1] && GameArray[0, 1] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Col 2 ";

                        if (GameArray[0, 1] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[0, 1] = GameSpaceState.Winning;
                        GameCheckArray[1, 1] = GameSpaceState.Winning;
                        GameCheckArray[2, 1] = GameSpaceState.Winning;
                    }
                    //col 3
                    if (GameArray[0, 2] == GameArray[1, 2] && GameArray[1, 2] == GameArray[2, 2] && GameArray[0, 2] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Col 3 ";

                        if (GameArray[0, 2] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[0, 2] = GameSpaceState.Winning;
                        GameCheckArray[1, 2] = GameSpaceState.Winning;
                        GameCheckArray[2, 2] = GameSpaceState.Winning;
                    }
                    //Diangnal checks
                    //Diag /
                    if (GameArray[0, 2] == GameArray[1, 1] && GameArray[1, 1] == GameArray[2, 0] && GameArray[0, 2] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Diag / ";

                        if (GameArray[0, 2] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[0, 2] = GameSpaceState.Winning;
                        GameCheckArray[1, 1] = GameSpaceState.Winning;
                        GameCheckArray[2, 0] = GameSpaceState.Winning;
                    }
                    //Diag \
                    if (GameArray[2, 2] == GameArray[1, 1] && GameArray[1, 1] == GameArray[0, 0] && GameArray[0, 0] != GameSpaceState.Empty)
                    {
                        if (words.Length > 0)
                        {
                            words += "+ ";
                        }
                        words += "Diag "+"\\ ";

                        if (GameArray[2, 2] == GameSpaceState.O)
                        {
                            Winner = Oimage;
                            winner = "O ";
                        }
                        else
                        {
                            Winner = Ximage;
                            winner = "X ";
                        }

                        GameCheckArray[2, 2] = GameSpaceState.Winning;
                        GameCheckArray[1, 1] = GameSpaceState.Winning;
                        GameCheckArray[0, 0] = GameSpaceState.Winning;
                    }



                    if (words.Length > 0)
                    {
                        winner += "Wins!";
                        currentGameState = GameState.GameOver;
                    }
                    else
                    {
                        int EmptySpaces = 0;
                        foreach (var item in GameArray)
                        {
                            if (item == GameSpaceState.Empty)
                                EmptySpaces += 1;
                        }

                        if(EmptySpaces == 0)
                        {
                            currentGameState = GameState.GameOver;
                            winner += "Its A Tie!";
                        }
                        else
                        {
                            currentGameState = GameState.WaitForPlayerMove;
                        }
                        
                    }

                    


                    break;
                case GameState.GameOver:

                    if (currentMouseState.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton != ButtonState.Pressed)
                    {
                        currentGameState = GameState.Initialize;
                    }


                    break;
                default:
                    break;
            }

           

            
            base.Update(gameTime);

            previousMouseState = currentMouseState;
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.BlueViolet);
            Texture2D GameTempToken = Ximage;

            Texture2D GameToken = Ximage;

            if (nextTokenToBePlayed == GameSpaceState.O)
            {
                GameToken = Oimage;
            }

            


            spriteBatch.Begin();

            if (currentGameState != GameState.GameOver)
                spriteBatch.Draw(background, Vector2.One, Color.White);
            else
                GraphicsDevice.Clear(Color.WhiteSmoke);



            switch (currentGameState)
            {
                case GameState.Initialize:

                    break;
                case GameState.WaitForPlayerMove:

                    


                    for(int row = 0; row < GameArray.GetLength(0); row++)
                    {
                        for (int col = 0; col < GameArray.GetLength(1); col++)
                        {
                            if (GameArray[row,col] == GameSpaceState.X)
                            {
                                GameTempToken = Ximage;
                                spriteBatch.Draw(GameTempToken, GameBoardSpaces[row, col], Color.Wheat);
                            }
                            else if(GameArray[row, col] == GameSpaceState.O)
                            {
                                GameTempToken = Oimage;
                                spriteBatch.Draw(GameTempToken, GameBoardSpaces[row, col], Color.Wheat);
                            }                
                                                     
                                                                                  
                        }

                    }

                    spriteBatch.Draw(GameToken, currentDrawPos, Color.White);
                    break;
                case GameState.MakePlayerMove:

                    

                    break;
                case GameState.EvalPlayerMove:
                    
                    


                    break;
                case GameState.GameOver:



                    for (int row = 0; row < GameArray.GetLength(0); row++)
                    {
                        for (int col = 0; col < GameArray.GetLength(1); col++)
                        {
                            if (GameCheckArray[row, col] == GameSpaceState.Winning)
                            {

                                spriteBatch.Draw(Winner, GameBoardSpaces[row, col], Color.Black);
                            }



                        }

                    }

                    spriteBatch.DrawString(arial, words, new Vector2(windowWidth / 2 - arial.MeasureString(words).X /2, windowHeight/2 + arial.MeasureString(words).Y / 2), Color.MonoGameOrange);
                    spriteBatch.DrawString(arial, winner, new Vector2(windowWidth / 2 - arial.MeasureString(winner).X / 2, windowHeight / 2 - arial.MeasureString(winner).Y), Color.MonoGameOrange);

                                       
                    break;
                default:

                    break;
            }              

                    
                                              
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
